Authors
=======

Also see https://github.com/GitbookIO/gitbook/graphs/contributors.
Names below are ordered by first contribution.

Author
------

- Samy Pessé <samypesse@gmail.com> (@SamyPesse)
- Aaron O'Mullan <aaron.omullan@gmail.com> (@AaronO)


Contributors
------------

- Nijiko Yonskai (@Nijikokun)
- Herman Starikov (@Hermanya)

Translators
------------

- German
    - Winnie (@winniehell)
- Italian
    - Giulio Bonanome (@gbonanome)
- Russian
    - Andrey Akinshin (@AndreyAkinshin)
- Norwegian
    - Knut Melvær (@kmelve)
- Persian (Farsi)
    - Mohammad Hossein Mojtahedi (@mhm5000)
- Polish
    - Łukasz Szeremeta (@lszeremeta)
- Portuguese
    - Ryan O'Mullan (@RyanOM)
- Spanish
    - Ryan O'Mullan (@RyanOM)
- Simplifiled Chinese
    - Hu Hao (@howiehu)
- Traditional Chinese
    - Hu Hao (@howiehu)
- French
    - Samy Pessé (@SamyPesse)
- Romanian
        - Iancu Aurel (@awrelll)
- Finnish
    - Tommi Savikko (@savikko)
- Japanese
    - Iancu Aurel (@awrelll)
- Korean
    - Iancu Aurel (@awrelll)
    - SangYeob Yu (@deminoth)
- Vietnamese
    - Hong Nguyen (@nghong)
- Hebrew
    - @a-moses
- Ukrainian
    - @Karnaukhov
