var $ = require('jquery');

module.exports = $({});

