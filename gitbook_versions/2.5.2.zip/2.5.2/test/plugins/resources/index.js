module.exports = {
    website: {
        js: [
            "https://cdn.mathjax.org/mathjax/2.4-latest/MathJax.js?config=TeX-AMS-MML_HTMLorMML"
        ]
    },
    ebook: {
        css: [
            "test"
        ]
    }
};
