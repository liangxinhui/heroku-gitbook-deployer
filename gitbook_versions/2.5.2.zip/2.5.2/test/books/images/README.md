# Tests for Images

# SVG relative image


### Convert SVG to PNG
![test.svg](test.svg)

### Should only convert it once
![test.svg](test.svg)

### Download remote images
![remote image](http://upload.wikimedia.org/wikipedia/commons/b/b0/NewTux.svg)

### Remote images with same filename
![youtube1](http://img.youtube.com/vi/9bZkp7q19f0/0.jpg)
![youtube2](http://img.youtube.com/vi/IkV2HQLAKHY/0.jpg)

