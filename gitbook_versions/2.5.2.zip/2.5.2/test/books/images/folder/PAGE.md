### Images from other folder
![test.svg](../test.svg)

