module.exports = {
    "title": "js-config"
};
