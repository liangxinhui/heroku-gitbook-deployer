# Readme

Block without language

```
test 1
```

Block with a language

```lang
test 2
```

Inline code: `test 3`
Inline code with html: `<test>`